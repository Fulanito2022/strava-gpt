from fastapi import FastAPI, HTTPException, Request, Header
from fastapi.responses import JSONResponse, PlainTextResponse
from pydantic import BaseModel
from dateutil import parser as dtp
from .config import ADMIN_TOKEN, BASE_URL, STRAVA_CLIENT_ID, STRAVA_CLIENT_SECRET
from .storage import upsert_token, get_token, save_or_update_activity, query_runs
from .strava import exchange_code_for_token, ensure_fresh_token, list_activities, get_activity
from .stats import summarize_runs
from . import auth as oauth

app = FastAPI(title="Strava GPT Backend", version="1.0.0")
app.include_router(oauth.router)

ATHLETE_ID_SINGLETON: int | None = None  # para uso personal (1 atleta)

@app.get("/health")
def health():
    return {"ok": True}

@app.get("/oauth/callback")
async def oauth_callback(code: str | None = None, error: str | None = None):
    if error:
        raise HTTPException(400, f"OAuth error: {error}")
    if not code:
        raise HTTPException(400, "Falta code")
    data = await exchange_code_for_token(code)
    access_token = data["access_token"]
    refresh_token = data["refresh_token"]
    expires_at = int(data["expires_at"])
    athlete_id = data["athlete"]["id"]

    upsert_token(athlete_id, access_token, refresh_token, expires_at)
    global ATHLETE_ID_SINGLETON
    ATHLETE_ID_SINGLETON = athlete_id

    return PlainTextResponse("Autorización correcta. Ya puedes usar el GPT.")

# --- Admin: crear suscripción webhook (llámalo una vez) ---
class SubReq(BaseModel):
    verify_token: str = "verify"

@app.post("/admin/subscribe")
async def admin_subscribe(authorization: str = Header(None)):
    if authorization != f"Bearer {ADMIN_TOKEN}":
        raise HTTPException(401, "No autorizado")
    import httpx
    async with httpx.AsyncClient() as c:
        r = await c.post("https://www.strava.com/api/v3/push_subscriptions", data={
            "client_id": STRAVA_CLIENT_ID,
            "client_secret": STRAVA_CLIENT_SECRET,
            "callback_url": f"{BASE_URL}/strava/webhook",
            "verify_token": "verify",
        })
        return r.json()

# --- Webhook verification ---
@app.get("/strava/webhook")
async def strava_verify(request: Request):
    # Soporta tanto los nombres 'hub.*' oficiales como fallback simple
    qp = request.query_params
    verify_token = qp.get("hub.verify_token") or qp.get("token")
    challenge = qp.get("hub.challenge") or qp.get("challenge")
    if verify_token != "verify":
        raise HTTPException(403, "verify_token incorrecto")
    return {"hub.challenge": challenge}

# --- Webhook events ---
class Event(BaseModel):
    object_type: str
    object_id: int
    aspect_type: str
    owner_id: int
    subscription_id: int | None = None
    event_time: int | None = None
    updates: dict | None = None

@app.post("/strava/webhook")
async def strava_event(ev: Event):
    if ev.object_type != "activity":
        return {"ignored": True}

    token_row = get_token(ev.owner_id)
    if not token_row:
        return {"error": "Sin token para este atleta"}

    token_row = await ensure_fresh_token(token_row, upsert_token)
    act = await get_activity(token_row.access_token, ev.object_id)
    # Guardar solo si es run
    if act.get("type") == "Run":
        save_or_update_activity(act, athlete_id=ev.owner_id)
    return {"ok": True}

# --- Endpoint para el GPT: actividades por fechas ---
@app.get("/activities")
async def activities(start: str, end: str):
    """Lista actividades de running entre start y end (ISO YYYY-MM-DD)."""
    if not ATHLETE_ID_SINGLETON:
        raise HTTPException(400, "Falta autorizar OAuth primero")
    # Normalizamos a ISO con hora
    s = dtp.isoparse(start).replace(tzinfo=None)
    e = dtp.isoparse(end).replace(tzinfo=None)
    runs = query_runs(ATHLETE_ID_SINGLETON, s.isoformat(), e.isoformat())
    return [{
        "id": r.id,
        "date": r.start_date.isoformat(),
        "name": r.name,
        "distance_km": round(r.distance_m/1000, 2),
        "moving_time_min": round(r.moving_time_s/60, 1),
        "avg_hr": r.average_heartrate,
        "elev_gain_m": r.total_elevation_gain_m,
        "avg_pace": None,
    } for r in runs]

# --- Resumen por fechas (para respuestas rápidas del GPT) ---
@app.get("/stats/summary")
async def stats_summary(start: str, end: str):
    if not ATHLETE_ID_SINGLETON:
        raise HTTPException(400, "Falta autorizar OAuth primero")
    s = dtp.isoparse(start).replace(tzinfo=None)
    e = dtp.isoparse(end).replace(tzinfo=None)
    runs = query_runs(ATHLETE_ID_SINGLETON, s.isoformat(), e.isoformat())
    summary = summarize_runs(runs)
    return summary

# --- Utilidad: import inicial (pull) para poblar la DB sin esperar webhooks ---
@app.post("/admin/initial-import")
async def initial_import(authorization: str = Header(None), days: int = 365):
    if authorization != f"Bearer {ADMIN_TOKEN}":
        raise HTTPException(401, "No autorizado")
    if not ATHLETE_ID_SINGLETON:
        raise HTTPException(400, "Falta autorizar OAuth primero")
    token_row = get_token(ATHLETE_ID_SINGLETON)
    token_row = await ensure_fresh_token(token_row, upsert_token)
    from time import time
    after = int(time()) - days*86400
    page = 1
    while True:
        acts = await list_activities(token_row.access_token, after=after, page=page)
        if not acts:
            break
        for a in acts:
            if a.get("type") == "Run":
                # enriquecer con best_efforts llamando al detalle
                det = await get_activity(token_row.access_token, a["id"])
                save_or_update_activity(det, athlete_id=ATHLETE_ID_SINGLETON)
        page += 1
    return {"imported": True}
